var searchData=
[
  ['desktop',['Desktop',['../classcmemo__desktop_1_1_desktop.html',1,'cmemo_desktop']]],
  ['document',['Document',['../classckit_1_1ckit__textwidget_1_1_document.html',1,'ckit::ckit_textwidget']]]
];
