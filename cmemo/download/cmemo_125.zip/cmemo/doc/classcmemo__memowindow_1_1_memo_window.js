var classcmemo__memowindow_1_1_memo_window =
[
    [ "configure", "classcmemo__memowindow_1_1_memo_window.html#adf02e4896cbf6ef8ebfef2c9e858b65d", null ],
    [ "command_Edit", "classcmemo__memowindow_1_1_memo_window.html#a2b1e93bbee459a577bf37cc0755c67fb", null ],
    [ "command_SetClipboard", "classcmemo__memowindow_1_1_memo_window.html#ac41a93537667de2724a8cd090a3b32a2", null ],
    [ "command_AppendFromClipboard", "classcmemo__memowindow_1_1_memo_window.html#a663242747e613b9134575248b930b664", null ],
    [ "command_Undo", "classcmemo__memowindow_1_1_memo_window.html#a5fe83d9d6bbfdd7d32775c09b37360fa", null ],
    [ "command_Delete", "classcmemo__memowindow_1_1_memo_window.html#ab83ddc7028ef1f976fd9cd694bfceefb", null ],
    [ "command_SelectColor", "classcmemo__memowindow_1_1_memo_window.html#ac188edac26a6dd6f7fd3891d3b6a54e9", null ],
    [ "command_ToggleLineMode", "classcmemo__memowindow_1_1_memo_window.html#a2053bc9d8a836f216d4ba6d497f9c21d", null ]
];