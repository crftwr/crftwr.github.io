var group__textwidget =
[
    [ "Lexer", "classckit_1_1ckit__textwidget_1_1_lexer.html", null ],
    [ "TextLexer", "classckit_1_1ckit__textwidget_1_1_text_lexer.html", null ],
    [ "RegexLexer", "classckit_1_1ckit__textwidget_1_1_regex_lexer.html", null ],
    [ "Mode", "classckit_1_1ckit__textwidget_1_1_mode.html", null ],
    [ "Point", "classckit_1_1ckit__textwidget_1_1_point.html", null ],
    [ "Selection", "classckit_1_1ckit__textwidget_1_1_selection.html", null ],
    [ "Document", "classckit_1_1ckit__textwidget_1_1_document.html", null ],
    [ "Search", "classckit_1_1ckit__textwidget_1_1_search.html", null ],
    [ "TextWidget", "classckit_1_1ckit__textwidget_1_1_text_widget.html", [
      [ "configure", "classckit_1_1ckit__textwidget_1_1_text_widget.html#a926fbba338fc9e11437beccb27e11ba7", null ],
      [ "getIndexFromColumn", "classckit_1_1ckit__textwidget_1_1_text_widget.html#a307f8526300916648562ee15647fed81", null ]
    ] ]
];