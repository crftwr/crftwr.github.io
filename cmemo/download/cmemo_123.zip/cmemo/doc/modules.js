var modules =
[
    [ "メインウインドウ機能", "group__mainwindow.html", null ],
    [ "コマンド機能", "group__command.html", "group__command" ],
    [ "リストウインドウ機能", "group__listwindow.html", null ],
    [ "メッセージボックス機能", "group__msgbox.html", null ],
    [ "スレッドサポート機能", "group__threadutil.html", "group__threadutil" ],
    [ "サブプロセス実行機能", "group__subprocess.html", "group__subprocess" ],
    [ "ウィジェット機能", "group__widget.html", "group__widget" ],
    [ "テーマ機能", "group__theme.html", "group__theme" ],
    [ "設定スクリプト関連", "group__userconfig.html", "group__userconfig" ],
    [ "その他雑多な機能", "group__misc.html", "group__misc" ],
    [ "Desktop", "group__desktop.html", "group__desktop" ],
    [ "グローバル関数", "group__global.html", "group__global" ],
    [ "テキスト編集ウィジェット機能", "group__textwidget.html", "group__textwidget" ]
];