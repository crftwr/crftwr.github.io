var classckit_1_1ckit__subprocess_1_1_sub_process =
[
    [ "__init__", "classckit_1_1ckit__subprocess_1_1_sub_process.html#ac775ee34451fdfa742b318538164070e", null ],
    [ "__call__", "classckit_1_1ckit__subprocess_1_1_sub_process.html#ae844e0019d38360a86bac1474132db3c", null ],
    [ "cancel", "classckit_1_1ckit__subprocess_1_1_sub_process.html#a9691897ab0716f1539f3034e6d27ba56", null ]
];