var searchData=
[
  ['hotkeywidget_68',['HotKeyWidget',['../classckit_1_1ckit__widget_1_1_hot_key_widget.html',1,'ckit::ckit_widget']]]
];
