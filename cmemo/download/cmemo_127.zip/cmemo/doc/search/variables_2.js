var searchData=
[
  ['wordbreak_5ffilename_268',['wordbreak_Filename',['../group__misc.html#ga1d3d0da8ab45b95cca9507870e49cd3d',1,'ckit::ckit_misc']]],
  ['wordbreak_5ftextfile_269',['wordbreak_TextFile',['../group__misc.html#gaef19a7e76c9533ad2ec1b921ef6aefd4',1,'ckit::ckit_misc']]]
];
