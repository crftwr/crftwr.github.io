var searchData=
[
  ['desktop_150',['Desktop',['../classcmemo__desktop_1_1_desktop.html',1,'cmemo_desktop']]],
  ['document_151',['Document',['../classckit_1_1ckit__textwidget_1_1_document.html',1,'ckit::ckit_textwidget']]]
];
