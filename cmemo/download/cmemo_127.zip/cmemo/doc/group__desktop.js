var group__desktop =
[
    [ "Desktop", "classcmemo__desktop_1_1_desktop.html", [
      [ "setFont", "classcmemo__desktop_1_1_desktop.html#adafb2db10bb19e6341323eba988644ad", null ],
      [ "acquireUserInputOwnership", "classcmemo__desktop_1_1_desktop.html#af951d790d1e6ddd2aafd6afb29e4ab26", null ],
      [ "releaseUserInputOwnership", "classcmemo__desktop_1_1_desktop.html#a9f8319c81ece1f10f8ea22911c97e52d", null ],
      [ "configure", "classcmemo__desktop_1_1_desktop.html#adf02e4896cbf6ef8ebfef2c9e858b65d", null ]
    ] ]
];