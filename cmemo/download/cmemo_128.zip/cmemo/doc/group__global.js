var group__global =
[
    [ "popMenu", "group__global.html#gac81da988da9eac1495ff6f03cbcbeadf", null ],
    [ "popMessageBox", "group__global.html#ga1b8baef3e572d82740a172a5dbae8dfb", null ]
];