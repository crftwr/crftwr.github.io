var searchData=
[
  ['releaseuserinputownership',['releaseUserInputOwnership',['../classcmemo__desktop_1_1_desktop.html#aadfe166bd6b2f0cb24fa92af3e64a0a4',1,'cmemo_desktop::Desktop']]],
  ['reloadconfigscript',['reloadConfigScript',['../group__userconfig.html#ga7840a38cb4f95e4fa50637a7c8f38322',1,'ckit::ckit_userconfig']]],
  ['remove',['remove',['../classcmemo__listwindow_1_1_list_window.html#a484e6bdc056a91ba1dc9335b5eb779f8',1,'cmemo_listwindow.ListWindow.remove()'],['../classckit_1_1ckit__threadutil_1_1_cron_table.html#a484e6bdc056a91ba1dc9335b5eb779f8',1,'ckit.ckit_threadutil.CronTable.remove()']]],
  ['removebom',['removeBom',['../group__misc.html#ga414770bb92d8dfb68459a968edbc7fb1',1,'ckit::ckit_misc']]],
  ['replacepath',['replacePath',['../group__misc.html#ga5fd020621b2af9314ff52d2f6a5f1c24',1,'ckit::ckit_misc']]],
  ['restart',['restart',['../classckit_1_1ckit__threadutil_1_1_job_item.html#ac035369f12e9417eb1a18896a6888f05',1,'ckit.ckit_threadutil.JobItem.restart()'],['../classckit_1_1ckit__threadutil_1_1_job_queue.html#ac035369f12e9417eb1a18896a6888f05',1,'ckit.ckit_threadutil.JobQueue.restart()']]],
  ['rootpath',['rootPath',['../group__misc.html#ga8494dc22b69ff801674b6f39cff18886',1,'ckit::ckit_misc']]]
];
