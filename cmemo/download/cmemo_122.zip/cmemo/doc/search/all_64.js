var searchData=
[
  ['datapath',['dataPath',['../group__misc.html#ga22cb466c9486b2b62ae7b0bd998540a3',1,'ckit::ckit_misc']]],
  ['defaultcrontable',['defaultCronTable',['../classckit_1_1ckit__threadutil_1_1_cron_table.html#ae57d088efd6c54680ee1406c5b0ae14c',1,'ckit::ckit_threadutil::CronTable']]],
  ['defaultqueue',['defaultQueue',['../classckit_1_1ckit__threadutil_1_1_job_queue.html#adabdb4b6a2692b24683a51a7d536468c',1,'ckit::ckit_threadutil::JobQueue']]],
  ['deletefilesusingrecyclebin',['deleteFilesUsingRecycleBin',['../group__misc.html#ga80c0ff53e3096b206694b4bc171bcbe1',1,'ckit::ckit_misc']]],
  ['desktop',['Desktop',['../group__desktop.html',1,'']]],
  ['desktop',['Desktop',['../classcmemo__desktop_1_1_desktop.html',1,'cmemo_desktop']]],
  ['destroy',['destroy',['../classckit_1_1ckit__threadutil_1_1_job_queue.html#a0ced48ce1d2b232eb793c028f4a75b89',1,'ckit.ckit_threadutil.JobQueue.destroy()'],['../classckit_1_1ckit__threadutil_1_1_cron_table.html#a0ced48ce1d2b232eb793c028f4a75b89',1,'ckit.ckit_threadutil.CronTable.destroy()']]],
  ['detecttextencoding',['detectTextEncoding',['../group__misc.html#ga4ff578f23299121e549e3464123ed394',1,'ckit::ckit_misc']]],
  ['document',['Document',['../classckit_1_1ckit__textwidget_1_1_document.html',1,'ckit::ckit_textwidget']]]
];
