var group__global =
[
    [ "popMenu", "group__global.html#ga145b50f4f98f79a2f7a674a0481fd7fa", null ],
    [ "popMessageBox", "group__global.html#ga9e91ed7bacf9904a3a1739bb111f73d5", null ]
];