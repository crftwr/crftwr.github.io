var classcmemo__memowindow_1_1_memo_window =
[
    [ "configure", "classcmemo__memowindow_1_1_memo_window.html#a926fbba338fc9e11437beccb27e11ba7", null ],
    [ "command_Edit", "classcmemo__memowindow_1_1_memo_window.html#a027602f566400a4fcd645da37d4e8f00", null ],
    [ "command_SetClipboard", "classcmemo__memowindow_1_1_memo_window.html#a9c7b4123b03a26f1aa9f4540430915e7", null ],
    [ "command_AppendFromClipboard", "classcmemo__memowindow_1_1_memo_window.html#a30bf5dde2c6c2d6e75bc076cb8f4aa18", null ],
    [ "command_Undo", "classcmemo__memowindow_1_1_memo_window.html#a2732e1f59b75287c80a7f18d30b11042", null ],
    [ "command_Delete", "classcmemo__memowindow_1_1_memo_window.html#a5338ec474f7925ea3976d8e39e77c060", null ],
    [ "command_SelectColor", "classcmemo__memowindow_1_1_memo_window.html#a189c6a655d64652e20b55b4c72a38225", null ],
    [ "command_ToggleLineMode", "classcmemo__memowindow_1_1_memo_window.html#a8c3b9b40010d93da94d4566c06354ed1", null ]
];