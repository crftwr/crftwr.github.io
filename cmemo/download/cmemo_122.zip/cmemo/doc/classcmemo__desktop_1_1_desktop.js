var classcmemo__desktop_1_1_desktop =
[
    [ "acquireUserInputOwnership", "classcmemo__desktop_1_1_desktop.html#a53d8ca035e3523be66bc0681d47604ff", null ],
    [ "releaseUserInputOwnership", "classcmemo__desktop_1_1_desktop.html#aadfe166bd6b2f0cb24fa92af3e64a0a4", null ],
    [ "configure", "classcmemo__desktop_1_1_desktop.html#a926fbba338fc9e11437beccb27e11ba7", null ]
];