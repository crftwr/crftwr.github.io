var searchData=
[
  ['iscanceled',['isCanceled',['../classckit_1_1ckit__threadutil_1_1_job_item.html#af6627807d1213d586b9408e7dfcbe567',1,'ckit.ckit_threadutil.JobItem.isCanceled()'],['../classckit_1_1ckit__threadutil_1_1_cron_item.html#af6627807d1213d586b9408e7dfcbe567',1,'ckit.ckit_threadutil.CronItem.isCanceled()']]],
  ['ispaused',['isPaused',['../classckit_1_1ckit__threadutil_1_1_job_item.html#a9e23c770dbbe912dfc46c8216f3332ce',1,'ckit::ckit_threadutil::JobItem']]]
];
