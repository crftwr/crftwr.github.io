var searchData=
[
  ['jobitem',['JobItem',['../classckit_1_1ckit__threadutil_1_1_job_item.html',1,'ckit::ckit_threadutil']]],
  ['jobqueue',['JobQueue',['../classckit_1_1ckit__threadutil_1_1_job_queue.html',1,'ckit::ckit_threadutil']]]
];
