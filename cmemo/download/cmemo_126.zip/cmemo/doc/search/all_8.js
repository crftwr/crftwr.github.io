var searchData=
[
  ['iscanceled',['isCanceled',['../classckit_1_1ckit__threadutil_1_1_job_item.html#a892b73e8f432f36076b07e7ee8f67187',1,'ckit.ckit_threadutil.JobItem.isCanceled()'],['../classckit_1_1ckit__threadutil_1_1_cron_item.html#a892b73e8f432f36076b07e7ee8f67187',1,'ckit.ckit_threadutil.CronItem.isCanceled()']]],
  ['ispaused',['isPaused',['../classckit_1_1ckit__threadutil_1_1_job_item.html#a8c5011fe1e72b47743e5df1266c451cd',1,'ckit::ckit_threadutil::JobItem']]]
];
