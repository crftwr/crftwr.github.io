var searchData=
[
  ['urlcommand',['UrlCommand',['../classclnch__mainwindow_1_1_main_window.html#abfb6dc723f5bcb8ccaead37ba8ecdb12',1,'clnch_mainwindow::MainWindow']]]
];
