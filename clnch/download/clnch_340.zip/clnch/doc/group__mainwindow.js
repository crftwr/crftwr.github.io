var group__mainwindow =
[
    [ "MainWindow", "classclnch__mainwindow_1_1_main_window.html", [
      [ "subThreadCall", "classclnch__mainwindow_1_1_main_window.html#adcfd90af5eb5cc28a9814acc3cfabd39", null ],
      [ "subProcessCall", "classclnch__mainwindow_1_1_main_window.html#aadf18b7a400587360366b7d3267d2964", null ],
      [ "commandLine", "classclnch__mainwindow_1_1_main_window.html#a3e0c33dece17fa4f7c367b8557dc9438", null ],
      [ "resetPos", "classclnch__mainwindow_1_1_main_window.html#aa94ac4195cb4eb623439a5d5ce1f1040", null ],
      [ "configure", "classclnch__mainwindow_1_1_main_window.html#adf02e4896cbf6ef8ebfef2c9e858b65d", null ],
      [ "command_Edit", "classclnch__mainwindow_1_1_main_window.html#a2b1e93bbee459a577bf37cc0755c67fb", null ],
      [ "command_ContextMenu", "classclnch__mainwindow_1_1_main_window.html#a6d0d821a3881331fd1054d3e498c233f", null ],
      [ "command_Quit", "classclnch__mainwindow_1_1_main_window.html#ad7103c6e7ccedbd0a1d8d70876cbde79", null ],
      [ "command_MusicList", "classclnch__mainwindow_1_1_main_window.html#a788777c2535d41d2b13fe715bc37a862", null ],
      [ "command_MusicPlay", "classclnch__mainwindow_1_1_main_window.html#a7452355b3bfaa985f2d8d434528a74a6", null ],
      [ "command_MusicStop", "classclnch__mainwindow_1_1_main_window.html#ace0ea6716f2f20e19efc15c84a8010f8", null ],
      [ "ShellExecuteCommand", "classclnch__mainwindow_1_1_main_window.html#afbed6b181609a379c178b2168b9f9b02", null ],
      [ "UrlCommand", "classclnch__mainwindow_1_1_main_window.html#afb9565e75003bcd5cc794e5a6eeab7d5", null ],
      [ "command_History", "classclnch__mainwindow_1_1_main_window.html#af8ea8f0ad50f891bf39392c4883461ea", null ],
      [ "command_RemoveHistory", "classclnch__mainwindow_1_1_main_window.html#a48ff4409283dce8f0e303272a1458ee0", null ],
      [ "command_CommandList", "classclnch__mainwindow_1_1_main_window.html#ac15cc97975fac5196202a3b41918dd95", null ],
      [ "command_ConfigMenu", "classclnch__mainwindow_1_1_main_window.html#aee50e1ee06f8f04c42cb274f6daed746", null ],
      [ "command_Reload", "classclnch__mainwindow_1_1_main_window.html#a3b781903645abc36a52ae0f62fdf29fa", null ],
      [ "command_ConsoleOpen", "classclnch__mainwindow_1_1_main_window.html#ae33dc7f327f022e131acd61149c26ae0", null ],
      [ "command_ConsoleClose", "classclnch__mainwindow_1_1_main_window.html#a8e31360f910c2c2bd18484d091824810", null ],
      [ "command_ConsoleToggle", "classclnch__mainwindow_1_1_main_window.html#a08b484a23c053e1904e25c633bab20e0", null ],
      [ "command_AutoCompleteOn", "classclnch__mainwindow_1_1_main_window.html#a278cf7d54679e1ae25c9e2da05c0bbf5", null ],
      [ "command_AutoCompleteOff", "classclnch__mainwindow_1_1_main_window.html#a97ec2a28f52743859e713bbbbc369031", null ],
      [ "command_AutoCompleteToggle", "classclnch__mainwindow_1_1_main_window.html#abe2c01b2b2a2c064b85cdcb2cc3eef24", null ],
      [ "command_About", "classclnch__mainwindow_1_1_main_window.html#a4c476dd6e2e4e4640803d99a1316548e", null ]
    ] ]
];