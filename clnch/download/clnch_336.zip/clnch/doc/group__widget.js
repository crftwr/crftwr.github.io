var group__widget =
[
    [ "Widget", "classckit_1_1ckit__widget_1_1_widget.html", null ],
    [ "ButtonWidget", "classckit_1_1ckit__widget_1_1_button_widget.html", null ],
    [ "CheckBoxWidget", "classckit_1_1ckit__widget_1_1_check_box_widget.html", null ],
    [ "ChoiceWidget", "classckit_1_1ckit__widget_1_1_choice_widget.html", null ],
    [ "ColorWidget", "classckit_1_1ckit__widget_1_1_color_widget.html", null ],
    [ "HotKeyWidget", "classckit_1_1ckit__widget_1_1_hot_key_widget.html", null ],
    [ "EditWidget", "classckit_1_1ckit__widget_1_1_edit_widget.html", null ],
    [ "TimeWidget", "classckit_1_1ckit__widget_1_1_time_widget.html", null ],
    [ "ProgressBarWidget", "classckit_1_1ckit__widget_1_1_progress_bar_widget.html", null ]
];