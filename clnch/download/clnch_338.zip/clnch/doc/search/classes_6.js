var searchData=
[
  ['jobitem_177',['JobItem',['../classckit_1_1ckit__threadutil_1_1_job_item.html',1,'ckit::ckit_threadutil']]],
  ['jobqueue_178',['JobQueue',['../classckit_1_1ckit__threadutil_1_1_job_queue.html',1,'ckit::ckit_threadutil']]]
];
