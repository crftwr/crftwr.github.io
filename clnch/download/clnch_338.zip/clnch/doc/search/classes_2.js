var searchData=
[
  ['document_173',['Document',['../classckit_1_1ckit__textwidget_1_1_document.html',1,'ckit::ckit_textwidget']]]
];
