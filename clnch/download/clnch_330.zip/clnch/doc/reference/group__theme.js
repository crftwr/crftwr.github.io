var group__theme =
[
    [ "ThemePlane", "classckit_1_1ckit__theme_1_1_theme_plane.html", null ],
    [ "ThemePlane3x3", "classckit_1_1ckit__theme_1_1_theme_plane3x3.html", null ],
    [ "createThemeImage", "group__theme.html#gacf467a9f2104191983657896634530df", null ],
    [ "createThemeImage3x3", "group__theme.html#gaf90d7abb3f3b278e23e3b6aa2f034581", null ],
    [ "getColor", "group__theme.html#ga252720e443fa3f852873d8111a5cb28c", null ],
    [ "setTheme", "group__theme.html#ga6266ddaeb8fc6bfb75b6db7e19ad95de", null ],
    [ "setThemeDefault", "group__theme.html#ga1a6519877e4d48226303cea674a8eb66", null ]
];