var searchData=
[
  ['regexlexer',['RegexLexer',['../classckit_1_1ckit__textwidget_1_1_regex_lexer.html',1,'ckit::ckit_textwidget']]],
  ['reloadconfigscript',['reloadConfigScript',['../group__userconfig.html#ga7840a38cb4f95e4fa50637a7c8f38322',1,'ckit::ckit_userconfig']]],
  ['remove',['remove',['../classclnch__listwindow_1_1_list_window.html#a484e6bdc056a91ba1dc9335b5eb779f8',1,'clnch_listwindow.ListWindow.remove()'],['../classckit_1_1ckit__threadutil_1_1_cron_table.html#a484e6bdc056a91ba1dc9335b5eb779f8',1,'ckit.ckit_threadutil.CronTable.remove()']]],
  ['removebom',['removeBom',['../group__misc.html#ga414770bb92d8dfb68459a968edbc7fb1',1,'ckit::ckit_misc']]],
  ['replacepath',['replacePath',['../group__misc.html#ga5fd020621b2af9314ff52d2f6a5f1c24',1,'ckit::ckit_misc']]],
  ['resetpos',['resetPos',['../classclnch__mainwindow_1_1_main_window.html#aa56f1da895054e44cf15649975765ea6',1,'clnch_mainwindow::MainWindow']]],
  ['restart',['restart',['../classckit_1_1ckit__threadutil_1_1_job_item.html#ac035369f12e9417eb1a18896a6888f05',1,'ckit.ckit_threadutil.JobItem.restart()'],['../classckit_1_1ckit__threadutil_1_1_job_queue.html#ac035369f12e9417eb1a18896a6888f05',1,'ckit.ckit_threadutil.JobQueue.restart()']]],
  ['rootpath',['rootPath',['../group__misc.html#ga8494dc22b69ff801674b6f39cff18886',1,'ckit::ckit_misc']]]
];
