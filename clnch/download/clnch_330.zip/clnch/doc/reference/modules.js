var modules =
[
    [ "リストウインドウ機能", "group__listwindow.html", "group__listwindow" ],
    [ "メインウインドウ機能", "group__mainwindow.html", "group__mainwindow" ],
    [ "その他雑多な機能", "group__misc.html", "group__misc" ],
    [ "メッセージボックス機能", "group__msgbox.html", "group__msgbox" ],
    [ "コマンド機能", "group__command.html", "group__command" ],
    [ "サブプロセス実行機能", "group__subprocess.html", "group__subprocess" ],
    [ "テキスト編集ウィジェット機能", "group__textwidget.html", "group__textwidget" ],
    [ "テーマ機能", "group__theme.html", "group__theme" ],
    [ "スレッドサポート機能", "group__threadutil.html", "group__threadutil" ],
    [ "設定スクリプト関連", "group__userconfig.html", "group__userconfig" ],
    [ "ウィジェット機能", "group__widget.html", "group__widget" ]
];