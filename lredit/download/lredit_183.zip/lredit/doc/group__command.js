var group__command =
[
    [ "CommandInfo", "classckit_1_1ckit__command_1_1_command_info.html", [
      [ "__init__", "classckit_1_1ckit__command_1_1_command_info.html#ae64f0875afe3067b97ba370b354b9213", null ],
      [ "args", "classckit_1_1ckit__command_1_1_command_info.html#a8187411843a6284ffb964ef3fb9fcab3", null ],
      [ "mod", "classckit_1_1ckit__command_1_1_command_info.html#a4b97eb97db2365148a5c3a5070f0cdd1", null ]
    ] ],
    [ "CommandSequence", "classckit_1_1ckit__command_1_1_command_sequence.html", null ]
];