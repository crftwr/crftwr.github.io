var classlredit__bookmark_1_1_bookmark_table =
[
    [ "__init__", "classlredit__bookmark_1_1_bookmark_table.html#ac775ee34451fdfa742b318538164070e", null ],
    [ "setBookmarkList", "classlredit__bookmark_1_1_bookmark_table.html#a3d63bf198b9eb7ef1c4be763e88da337", null ],
    [ "setBookmark", "classlredit__bookmark_1_1_bookmark_table.html#a9f5291e87fc8a3a81c5d68dc5f3b597b", null ],
    [ "getBookmarkList", "classlredit__bookmark_1_1_bookmark_table.html#abe9dd6938c9ecaf04afc3ecbcd6c128e", null ],
    [ "save", "classlredit__bookmark_1_1_bookmark_table.html#aba0970ece8740693d3b82e656500a9c0", null ],
    [ "load", "classlredit__bookmark_1_1_bookmark_table.html#a34b4d3a01c4a6233a80fcbda3ba28c7f", null ]
];