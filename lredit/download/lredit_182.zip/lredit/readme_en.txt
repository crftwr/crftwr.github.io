A text editor extendable by Python [ LREdit ]

Author: craftware
Contact: craftware@gmail.com
Development Environment: Python + VisualC++2019
Type: Freeware
Requirement: Windows 10 64bit
Website: http://sites.google.com/site/craftware/


For detail, refer to document.
doc/en/index.html

