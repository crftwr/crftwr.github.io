var group__commandline =
[
    [ "commandline_Launcher", "classlredit__commandline_1_1commandline___launcher.html", null ],
    [ "commandline_Open", "classlredit__commandline_1_1commandline___open.html", null ],
    [ "commandline_Document", "classlredit__commandline_1_1commandline___document.html", null ],
    [ "commandline_Mode", "classlredit__commandline_1_1commandline___mode.html", null ],
    [ "commandline_MinorMode", "classlredit__commandline_1_1commandline___minor_mode.html", null ],
    [ "commandline_Calculator", "classlredit__commandline_1_1commandline___calculator.html", null ],
    [ "commandline_Int32Hex", "classlredit__commandline_1_1commandline___int32_hex.html", null ],
    [ "candidate_Filename", "classlredit__commandline_1_1candidate___filename.html", null ],
    [ "History", "classlredit__history_1_1_history.html", [
      [ "__init__", "classlredit__history_1_1_history.html#ab54a54ace07469f36e7b329d2f604368", null ],
      [ "append", "classlredit__history_1_1_history.html#a85de3eeea5f9509984b3cfac1814fb6f", null ],
      [ "remove", "classlredit__history_1_1_history.html#a280b05f5809a3e0f24bc42fb86367be9", null ],
      [ "save", "classlredit__history_1_1_history.html#a270f03e5b5b1f06b453876eda7e80978", null ],
      [ "load", "classlredit__history_1_1_history.html#af0c9a1a42e1b7f676586e7861732fe97", null ],
      [ "candidateHandler", "classlredit__history_1_1_history.html#af5c2fff57b4de2b92340de880b0849d1", null ],
      [ "candidateRemoveHandler", "classlredit__history_1_1_history.html#ab690c6bd4b474d132b628cde679010f3", null ]
    ] ]
];