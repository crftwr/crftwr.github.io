var group__theme =
[
    [ "ThemePlane", "classckit_1_1ckit__theme_1_1_theme_plane.html", null ],
    [ "ThemePlane3x3", "classckit_1_1ckit__theme_1_1_theme_plane3x3.html", null ],
    [ "setTheme", "group__theme.html#ga8ec761192fb156289b7b7ce6c868b5f5", null ],
    [ "setThemeDefault", "group__theme.html#ga6e666c83856dbd84dbda6a1c556c699d", null ],
    [ "getColor", "group__theme.html#ga182e89fe206efc3e4dedada7b2875cfd", null ],
    [ "createThemeImage", "group__theme.html#ga7aaab5fc0cb8d94a546e743918ea22cc", null ],
    [ "createThemeImage3x3", "group__theme.html#ga46e7419d952095cb1320c436e8516163", null ]
];