var searchData=
[
  ['ext_5fmenu_5fitems_642',['ext_menu_items',['../classlredit__mainwindow_1_1_main_window.html#a0e4f457a618a99d8b23998acf9970d9d',1,'lredit_mainwindow::MainWindow']]]
];
