Text editor extendable by Python script [ LREdit ]

Author: craftware
Contact: craftware@gmail.com
Development Environment: Python + VC2010
Type: Freeware
Requirement: Windows XP/Vista/7/8
Website: http://sites.google.com/site/craftware/


For detail, refer to document.
doc/en/index.html

