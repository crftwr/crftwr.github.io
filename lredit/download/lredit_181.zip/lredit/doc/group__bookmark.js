var group__bookmark =
[
    [ "BookmarkTable", "classlredit__bookmark_1_1_bookmark_table.html", [
      [ "__init__", "classlredit__bookmark_1_1_bookmark_table.html#a3eb949589c851765531446d93390e8c0", null ],
      [ "setBookmarkList", "classlredit__bookmark_1_1_bookmark_table.html#a3d63bf198b9eb7ef1c4be763e88da337", null ],
      [ "setBookmark", "classlredit__bookmark_1_1_bookmark_table.html#a9f5291e87fc8a3a81c5d68dc5f3b597b", null ],
      [ "getBookmarkList", "classlredit__bookmark_1_1_bookmark_table.html#abe9dd6938c9ecaf04afc3ecbcd6c128e", null ],
      [ "save", "classlredit__bookmark_1_1_bookmark_table.html#a8a943ef37341c58451dd24afce4e747d", null ],
      [ "load", "classlredit__bookmark_1_1_bookmark_table.html#a9d26d3d8f0fd97184624d152b1e6de0e", null ]
    ] ]
];