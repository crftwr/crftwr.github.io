﻿Pythonスクリプトで拡張可能なテキストエディタ [ LREdit ]

著作者: craftware
連絡先: craftware@gmail.com
開発環境: Python + VC2015
種別: フリーウェア
動作環境: Windows 10 64bit
Webサイト: http://sites.google.com/site/craftware/


詳細については、ドキュメントを参照してください。
doc/ja/index.html

