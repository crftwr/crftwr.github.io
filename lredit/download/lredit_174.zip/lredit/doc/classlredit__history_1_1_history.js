var classlredit__history_1_1_history =
[
    [ "__init__", "classlredit__history_1_1_history.html#ac775ee34451fdfa742b318538164070e", null ],
    [ "append", "classlredit__history_1_1_history.html#a69e6c03a1e37f0277f464db19e5fd985", null ],
    [ "remove", "classlredit__history_1_1_history.html#a484e6bdc056a91ba1dc9335b5eb779f8", null ],
    [ "save", "classlredit__history_1_1_history.html#aba0970ece8740693d3b82e656500a9c0", null ],
    [ "load", "classlredit__history_1_1_history.html#a34b4d3a01c4a6233a80fcbda3ba28c7f", null ],
    [ "candidateHandler", "classlredit__history_1_1_history.html#a158d093180a2c17b8885b2f59287a3c9", null ],
    [ "candidateRemoveHandler", "classlredit__history_1_1_history.html#a9d905a1d9815fbe2f0fd8413be59c5d1", null ]
];