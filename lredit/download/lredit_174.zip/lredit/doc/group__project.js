var group__project =
[
    [ "Project", "classlredit__project_1_1_project.html", [
      [ "__init__", "classlredit__project_1_1_project.html#ac775ee34451fdfa742b318538164070e", null ],
      [ "parse", "classlredit__project_1_1_project.html#a143c53005fa478af7910376b2e108961", null ],
      [ "enumName", "classlredit__project_1_1_project.html#a6461b6ef7c7d064a28de5d214157edfa", null ],
      [ "enumFullpath", "classlredit__project_1_1_project.html#a0a9ce14c1a7fda23d10dd5c912859f49", null ],
      [ "isFileModified", "classlredit__project_1_1_project.html#a28cef46dc09121c1ddad1c31ed17f713", null ]
    ] ]
];