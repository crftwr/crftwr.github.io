var classlredit__bookmark_1_1_bookmark_table =
[
    [ "__init__", "classlredit__bookmark_1_1_bookmark_table.html#ac775ee34451fdfa742b318538164070e", null ],
    [ "setBookmarkList", "classlredit__bookmark_1_1_bookmark_table.html#a4cc24958696e3afccafd549fbae80eab", null ],
    [ "setBookmark", "classlredit__bookmark_1_1_bookmark_table.html#add5a2401a1a7e754bcb8db85d71eb86a", null ],
    [ "getBookmarkList", "classlredit__bookmark_1_1_bookmark_table.html#ac1ae642d7fdccf9ac1b7c30069414753", null ],
    [ "save", "classlredit__bookmark_1_1_bookmark_table.html#aba0970ece8740693d3b82e656500a9c0", null ],
    [ "load", "classlredit__bookmark_1_1_bookmark_table.html#a34b4d3a01c4a6233a80fcbda3ba28c7f", null ]
];