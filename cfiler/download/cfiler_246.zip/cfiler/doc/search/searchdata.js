var indexSectionsWithContent =
{
  0: "_abcdefghijlmnprstuwãåæçè",
  1: "bcdefhijlmnprstuw",
  2: "_acdegijlmnprstw",
  3: "amw",
  4: "ãåçè",
  5: "uæ"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Modules",
  5: "Pages"
};

