var searchData=
[
  ['wordbreak_5ffilename',['wordbreak_Filename',['../group__misc.html#ga624be72302511189eb34e67b3a5e4720',1,'ckit::ckit_misc']]],
  ['wordbreak_5ftextfile',['wordbreak_TextFile',['../group__misc.html#gaba5b35b61567740e1e959c009015f8cf',1,'ckit::ckit_misc']]]
];
