var group__resultwindow =
[
    [ "popResultWindow", "group__resultwindow.html#gafb8d6808af52fe07cfb856bb2bbd5279", null ]
];