var group__error =
[
    [ "Error", "classcfiler__error_1_1_error.html", null ],
    [ "NotExistError", "classcfiler__error_1_1_not_exist_error.html", null ],
    [ "CanceledError", "classcfiler__error_1_1_canceled_error.html", null ]
];