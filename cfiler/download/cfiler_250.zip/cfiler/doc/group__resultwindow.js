var group__resultwindow =
[
    [ "popResultWindow", "group__resultwindow.html#ga1d32a70355c07167b29213512bc341e1", null ]
];