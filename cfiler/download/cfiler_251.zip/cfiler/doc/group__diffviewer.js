var group__diffviewer =
[
    [ "DiffViewer", "classcfiler__diffviewer_1_1_diff_viewer.html", [
      [ "configure", "classcfiler__diffviewer_1_1_diff_viewer.html#adf02e4896cbf6ef8ebfef2c9e858b65d", null ],
      [ "command_ScrollUp", "classcfiler__diffviewer_1_1_diff_viewer.html#a83b12c116e9c7dfc5bce3f41e2fc86f7", null ],
      [ "command_ScrollDown", "classcfiler__diffviewer_1_1_diff_viewer.html#a8609ed2b8b83797741e35065bc0af789", null ],
      [ "command_PageUp", "classcfiler__diffviewer_1_1_diff_viewer.html#aa9940a5873ac7c20344645f14b0a9cee", null ],
      [ "command_PageDown", "classcfiler__diffviewer_1_1_diff_viewer.html#a9b6ca0e24aa07c4caea978cc410d1e5f", null ],
      [ "command_DiffPrev", "classcfiler__diffviewer_1_1_diff_viewer.html#a798ae26a0c0039fe0c9e524e2842e34b", null ],
      [ "command_DiffNext", "classcfiler__diffviewer_1_1_diff_viewer.html#a83392ae5bc149e2fb1a5de08293b4579", null ],
      [ "command_Close", "classcfiler__diffviewer_1_1_diff_viewer.html#aa0656832edaad37fa299d70757bea377", null ],
      [ "command_Edit", "classcfiler__diffviewer_1_1_diff_viewer.html#a2b1e93bbee459a577bf37cc0755c67fb", null ]
    ] ]
];