var group__textviewer =
[
    [ "TextViewer", "classcfiler__textviewer_1_1_text_viewer.html", [
      [ "destroy", "classcfiler__textviewer_1_1_text_viewer.html#a997ac515f8cd659ce5e5eabf1d6c3bd2", null ],
      [ "configure", "classcfiler__textviewer_1_1_text_viewer.html#adf02e4896cbf6ef8ebfef2c9e858b65d", null ],
      [ "centerOfWindowInPixel", "classcfiler__textviewer_1_1_text_viewer.html#a4119716bd80f0eff1f44255f26abc454", null ],
      [ "getVisibleRegion", "classcfiler__textviewer_1_1_text_viewer.html#a50323e3516128d1ed6322875f62677a2", null ],
      [ "command_ScrollUp", "classcfiler__textviewer_1_1_text_viewer.html#a83b12c116e9c7dfc5bce3f41e2fc86f7", null ],
      [ "command_ScrollDown", "classcfiler__textviewer_1_1_text_viewer.html#a8609ed2b8b83797741e35065bc0af789", null ],
      [ "command_PageUp", "classcfiler__textviewer_1_1_text_viewer.html#aa9940a5873ac7c20344645f14b0a9cee", null ],
      [ "command_PageDown", "classcfiler__textviewer_1_1_text_viewer.html#a9b6ca0e24aa07c4caea978cc410d1e5f", null ],
      [ "command_Edit", "classcfiler__textviewer_1_1_text_viewer.html#a2b1e93bbee459a577bf37cc0755c67fb", null ],
      [ "command_Search", "classcfiler__textviewer_1_1_text_viewer.html#a952021e085e3508ee556a777a9e06310", null ],
      [ "command_SearchNext", "classcfiler__textviewer_1_1_text_viewer.html#a07e5644240b57821845fb79dd5f41905", null ],
      [ "command_SearchPrev", "classcfiler__textviewer_1_1_text_viewer.html#a5621554050c936d13a2edf550959485f", null ],
      [ "command_ConfigMenu", "classcfiler__textviewer_1_1_text_viewer.html#aee50e1ee06f8f04c42cb274f6daed746", null ],
      [ "command_Close", "classcfiler__textviewer_1_1_text_viewer.html#aa0656832edaad37fa299d70757bea377", null ]
    ] ]
];