var searchData=
[
  ['diffviewer_333',['DiffViewer',['../classcfiler__diffviewer_1_1_diff_viewer.html',1,'cfiler_diffviewer']]],
  ['document_334',['Document',['../classckit_1_1ckit__textwidget_1_1_document.html',1,'ckit::ckit_textwidget']]]
];
