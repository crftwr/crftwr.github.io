var modules =
[
    [ "メインウインドウ機能", "group__mainwindow.html", "group__mainwindow" ],
    [ "ファイルリスト機能", "group__filelist.html", "group__filelist" ],
    [ "コマンドライン機能", "group__commandline.html", "group__commandline" ],
    [ "コマンド機能", "group__command.html", "group__command" ],
    [ "リストウインドウ機能", "group__listwindow.html", "group__listwindow" ],
    [ "メッセージボックス機能", "group__msgbox.html", "group__msgbox" ],
    [ "コンソールウインドウ機能", "group__resultwindow.html", "group__resultwindow" ],
    [ "テキストビューア機能", "group__textviewer.html", "group__textviewer" ],
    [ "差分ビューア機能", "group__diffviewer.html", "group__diffviewer" ],
    [ "画像ビューア機能", "group__imageviewer.html", "group__imageviewer" ],
    [ "スレッドサポート機能", "group__threadutil.html", "group__threadutil" ],
    [ "サブプロセス実行機能", "group__subprocess.html", "group__subprocess" ],
    [ "ウィジェット機能", "group__widget.html", "group__widget" ],
    [ "テーマ機能", "group__theme.html", "group__theme" ],
    [ "設定スクリプト関連", "group__userconfig.html", "group__userconfig" ],
    [ "エラーの定義", "group__error.html", "group__error" ],
    [ "その他雑多な機能", "group__misc.html", "group__misc" ],
    [ "テキスト編集ウィジェット機能", "group__textwidget.html", "group__textwidget" ]
];