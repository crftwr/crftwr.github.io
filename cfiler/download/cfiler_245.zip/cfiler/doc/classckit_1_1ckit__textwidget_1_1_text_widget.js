var classckit_1_1ckit__textwidget_1_1_text_widget =
[
    [ "configure", "classckit_1_1ckit__textwidget_1_1_text_widget.html#adf02e4896cbf6ef8ebfef2c9e858b65d", null ],
    [ "getIndexFromColumn", "classckit_1_1ckit__textwidget_1_1_text_widget.html#a307f8526300916648562ee15647fed81", null ]
];