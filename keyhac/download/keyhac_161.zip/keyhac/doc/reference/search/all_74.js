var searchData=
[
  ['terminateprocess',['terminateProcess',['../group__misc.html#ga42169ec083c154da6bf0b583eae3aed7',1,'ckit::ckit_misc']]],
  ['textencoding',['TextEncoding',['../classckit_1_1ckit__misc_1_1_text_encoding.html',1,'ckit::ckit_misc']]]
];
