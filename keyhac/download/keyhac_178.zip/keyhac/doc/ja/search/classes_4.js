var searchData=
[
  ['jobitem_240',['JobItem',['../classckit_1_1ckit__threadutil_1_1_job_item.html',1,'ckit::ckit_threadutil']]],
  ['jobqueue_241',['JobQueue',['../classckit_1_1ckit__threadutil_1_1_job_queue.html',1,'ckit::ckit_threadutil']]]
];
