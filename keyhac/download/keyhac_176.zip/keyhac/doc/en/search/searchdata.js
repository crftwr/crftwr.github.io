var indexSectionsWithContent =
{
  0: "_acdefghijklmnprstuw",
  1: "chijklmstuw",
  2: "_acdefghijmnprstuw",
  3: "cekmsw",
  4: "ciklmst",
  5: "cu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Modules",
  5: "Pages"
};

