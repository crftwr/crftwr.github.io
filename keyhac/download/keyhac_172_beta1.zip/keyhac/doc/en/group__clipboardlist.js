var group__clipboardlist =
[
    [ "cblister_ClipboardHistory", "classkeyhac__clipboard_1_1cblister___clipboard_history.html", [
      [ "push", "classkeyhac__clipboard_1_1cblister___clipboard_history.html#a67c54ee04a9415e707fb442bbc56a121", null ],
      [ "pop", "classkeyhac__clipboard_1_1cblister___clipboard_history.html#a2765ae24bbf034397818f83ca80b836c", null ],
      [ "rotate", "classkeyhac__clipboard_1_1cblister___clipboard_history.html#af23413dddc1c63178f8ffda4fe8db924", null ],
      [ "remove", "classkeyhac__clipboard_1_1cblister___clipboard_history.html#a8abef9a87503b73956ae1cb6d3d135e7", null ],
      [ "getListItems", "classkeyhac__clipboard_1_1cblister___clipboard_history.html#a80c08df37ed865085a8e9560d823fac0", null ]
    ] ],
    [ "cblister_FixedPhrase", "classkeyhac__clipboard_1_1cblister___fixed_phrase.html", null ]
];