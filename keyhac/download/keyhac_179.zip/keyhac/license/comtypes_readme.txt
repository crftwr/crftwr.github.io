
comtypes
========

comtypes - Pure Python COM package, based on the ctypes FFI library.

comtypes allows to define, call, and implement custom COM interfaces
in pure Python.  It works on Windows, 64-bit Windows, and Windows CE.

author="Thomas Heller"
author_email="theller@ctypes.org"
license="MIT License"
url="http://starship.python.net/crew/theller/comtypes/"


'Development Status :: 4 - Beta'
##'Development Status :: 5 - Production/Stable'
'Intended Audience :: Developers'
'License :: OSI Approved :: MIT License'
'Operating System :: Microsoft :: Windows'
'Operating System :: Microsoft :: Windows CE'
'Programming Language :: Python'
'Topic :: Software Development :: Libraries :: Python Modules'


