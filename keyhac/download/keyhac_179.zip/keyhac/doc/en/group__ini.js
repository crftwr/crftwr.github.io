var group__ini =
[
    [ "get", "group__ini.html#ga2e108fed75cd3e88b73feff0b565ac7e", null ],
    [ "getint", "group__ini.html#gaab95b0f7dc9e1e50b61f5e807c024537", null ],
    [ "set", "group__ini.html#gac49d7a0c962ae89786827c89598fa52f", null ],
    [ "setint", "group__ini.html#gae69e16f989a6f4e61206e9f80b6932e1", null ],
    [ "remove_section", "group__ini.html#gaa088be9010cfa27f39a0bf6223179ae4", null ],
    [ "remove_option", "group__ini.html#ga7e79274ff0b5d50dde0947b399edd95c", null ]
];