var searchData=
[
  ['ini_20file_20feature_453',['INI file feature',['../group__ini.html',1,'']]]
];
