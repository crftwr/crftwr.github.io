var searchData=
[
  ['unicoderange',['UnicodeRange',['../classckit_1_1ckit__misc_1_1_unicode_range.html',1,'ckit::ckit_misc']]]
];
