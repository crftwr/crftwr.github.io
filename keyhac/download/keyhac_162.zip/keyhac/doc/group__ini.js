var group__ini =
[
    [ "get", "group__ini.html#gaf9d731d72bdf57f6c8e5ed7bfe9fb477", null ],
    [ "getint", "group__ini.html#ga99b72b43652463119c5f35d936af45af", null ],
    [ "set", "group__ini.html#gaa6567b8a1b8c20d80069219c23df1ad8", null ],
    [ "setint", "group__ini.html#ga924b58587f899df0c4aebb517e12c605", null ],
    [ "remove_section", "group__ini.html#gae08cf2f948f851874ada2b7204e31206", null ],
    [ "remove_option", "group__ini.html#ga0e47133d2de27f1e3864618f54322eae", null ]
];