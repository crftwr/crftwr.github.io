var searchData=
[
  ['ini_20file_20feature',['INI file feature',['../group__ini.html',1,'']]]
];
